"""Pacote com a reimplementação em Python do exemplo de Filas da OCI."""
