"""
Carrega e valida as configurações da aplicação.

No exemplo original em Node.js, o OCID da fila, o endpoint e até a senha do
e-mail ficavam escritos direto no código. Aqui tudo vem de variáveis de
ambiente (ou de um arquivo .env), o que evita vazar segredos no repositório
e permite trocar de fila/região sem alterar o código.
"""

import os
from dataclasses import dataclass
from typing import Optional

from dotenv import load_dotenv


class ConfiguracaoInvalidaError(Exception):
    """Lançada quando uma variável obrigatória falta ou tem valor inválido."""


@dataclass(frozen=True)
class ConfigOci:
    """Onde está o arquivo de credenciais da OCI (o mesmo usado pela OCI CLI)."""

    arquivo: str
    perfil: str


@dataclass(frozen=True)
class ConfigFila:
    """Parâmetros da fila e do comportamento do consumidor."""

    queue_id: str
    endpoint: str
    # Quantas mensagens buscar por requisição (a API aceita de 1 a 20).
    limite_mensagens: int
    # Long polling: quanto tempo a OCI segura a requisição esperando chegar
    # mensagem (0 a 30 s). Substitui o "sleep de 5 segundos" do original.
    espera_segundos: int
    # Por quanto tempo uma mensagem que falhou fica invisível antes de
    # voltar para a fila e ser tentada de novo.
    visibilidade_falha_segundos: int
    # Canal opcional: se definido, o consumidor só lê mensagens desse canal
    # e o produtor publica nele. Vazio = fila inteira.
    canal: Optional[str] = None


@dataclass(frozen=True)
class ConfigEmail:
    """Configuração do envio de e-mail."""

    # "smtp" envia de verdade; "console" só imprime (útil para testar a fila).
    modo: str
    assunto: str
    servidor: str
    porta: int
    usuario: str
    senha: str
    remetente: str


@dataclass(frozen=True)
class Configuracao:
    """Agrupa todas as configurações da aplicação."""

    oci: ConfigOci
    fila: ConfigFila
    email: ConfigEmail


# --------------------------------------------------------------------------
# Funções auxiliares de leitura
# --------------------------------------------------------------------------

def _obrigatoria(nome: str) -> str:
    valor = os.getenv(nome, "").strip()
    if not valor:
        raise ConfiguracaoInvalidaError(f"A variável de ambiente {nome} é obrigatória.")
    return valor


def _texto(nome: str, padrao: str) -> str:
    return os.getenv(nome, "").strip() or padrao


def _inteiro(nome: str, padrao: int, minimo: int, maximo: int) -> int:
    bruto = os.getenv(nome, "").strip()
    if not bruto:
        return padrao
    try:
        valor = int(bruto)
    except ValueError as erro:
        raise ConfiguracaoInvalidaError(f"{nome} deve ser um número inteiro (recebido: {bruto!r}).") from erro
    if not minimo <= valor <= maximo:
        raise ConfiguracaoInvalidaError(f"{nome} deve estar entre {minimo} e {maximo} (recebido: {valor}).")
    return valor


# --------------------------------------------------------------------------
# Ponto de entrada do módulo
# --------------------------------------------------------------------------

def carregar_configuracao() -> Configuracao:
    """Lê o .env (se existir) e as variáveis de ambiente, validando cada uma."""
    load_dotenv()

    oci = ConfigOci(
        arquivo=_texto("OCI_CONFIG_FILE", "~/.oci/config"),
        perfil=_texto("OCI_CONFIG_PROFILE", "DEFAULT"),
    )

    fila = ConfigFila(
        queue_id=_obrigatoria("OCI_QUEUE_ID"),
        # rstrip evita URLs com "//" caso o endpoint seja informado com barra no final.
        endpoint=_obrigatoria("OCI_QUEUE_ENDPOINT").rstrip("/"),
        limite_mensagens=_inteiro("FILA_LIMITE_MENSAGENS", padrao=10, minimo=1, maximo=20),
        espera_segundos=_inteiro("FILA_ESPERA_SEGUNDOS", padrao=20, minimo=0, maximo=30),
        visibilidade_falha_segundos=_inteiro("FILA_VISIBILIDADE_FALHA_SEGUNDOS", padrao=30, minimo=0, maximo=43200),
        canal=os.getenv("FILA_CANAL", "").strip() or None,
    )

    modo = _texto("EMAIL_MODO", "console").lower()
    if modo not in ("smtp", "console"):
        raise ConfiguracaoInvalidaError("EMAIL_MODO deve ser 'smtp' ou 'console'.")

    # As credenciais de SMTP só são obrigatórias se o envio for real.
    exigir = _obrigatoria if modo == "smtp" else (lambda nome: _texto(nome, ""))
    usuario = exigir("SMTP_USUARIO")

    email = ConfigEmail(
        modo=modo,
        assunto=_texto("EMAIL_ASSUNTO", "Teste Fila OCI"),
        servidor=_texto("SMTP_SERVIDOR", "smtp.gmail.com"),
        porta=_inteiro("SMTP_PORTA", padrao=587, minimo=1, maximo=65535),
        usuario=usuario,
        senha=exigir("SMTP_SENHA"),
        remetente=_texto("SMTP_REMETENTE", usuario),
    )

    return Configuracao(oci=oci, fila=fila, email=email)
