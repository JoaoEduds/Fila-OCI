"""
Cliente HTTP que assina as requisições para a API REST da OCI.

Equivalente ao arquivo ociHttpRequest.js do exemplo original. Toda chamada à
API da OCI precisa ser assinada com a chave privada do usuário. O SDK oficial
para Python já tem o assinador (oci.signer.Signer), que funciona como um
"auth" da biblioteca requests: ele calcula e insere os cabeçalhos de
assinatura (Authorization, date, x-content-sha256...) em cada requisição.

Diferenças em relação ao original:
  * erros HTTP (401, 404, 500...) viram exceções com o código e a mensagem
    da OCI, em vez de serem ignorados e retornarem null;
  * o arquivo de configuração é validado assim que o cliente é criado;
  * existe timeout de rede, então a aplicação não trava para sempre;
  * uma única sessão HTTP é reaproveitada (mantém a conexão aberta).
"""

import logging
import os
from typing import Any, Optional

import oci
import requests

logger = logging.getLogger(__name__)


class OciHttpError(Exception):
    """Erro retornado pela API da OCI (resposta com status diferente de 2xx)."""

    def __init__(self, status: int, codigo: str, mensagem: str, request_id: Optional[str]):
        super().__init__(f"HTTP {status} {codigo}: {mensagem} (opc-request-id: {request_id})")
        self.status = status
        self.codigo = codigo
        self.mensagem = mensagem
        self.request_id = request_id

    @property
    def eh_temporario(self) -> bool:
        """Indica se vale a pena tentar de novo (limite de taxa ou erro do servidor)."""
        return self.status == 429 or self.status >= 500

    @classmethod
    def a_partir_da_resposta(cls, resposta: requests.Response) -> "OciHttpError":
        # A OCI devolve erros no formato {"code": "...", "message": "..."}.
        try:
            corpo = resposta.json()
        except ValueError:
            corpo = {}
        return cls(
            status=resposta.status_code,
            codigo=corpo.get("code", "Desconhecido"),
            mensagem=corpo.get("message", resposta.text[:200]),
            request_id=resposta.headers.get("opc-request-id"),
        )


class OciHttpClient:
    """Faz requisições HTTP assinadas para qualquer endpoint da OCI."""

    def __init__(self, arquivo_config: str, perfil: str, timeout_segundos: float = 60):
        # 1. Lê e valida o arquivo ~/.oci/config (o mesmo da OCI CLI).
        config = oci.config.from_file(os.path.expanduser(arquivo_config), perfil)
        oci.config.validate_config(config)

        # 2. Cria o assinador a partir das credenciais do perfil.
        self._assinador = oci.signer.Signer(
            tenancy=config["tenancy"],
            user=config["user"],
            fingerprint=config["fingerprint"],
            private_key_file_location=config.get("key_file"),
            pass_phrase=config.get("pass_phrase"),
            private_key_content=config.get("key_content"),
        )
        self._sessao = requests.Session()
        self._timeout = timeout_segundos

    def requisitar(
        self,
        metodo: str,
        url: str,
        params: Optional[dict] = None,
        corpo: Optional[dict] = None,
    ) -> Optional[Any]:
        """
        Envia uma requisição assinada e devolve o JSON da resposta (ou None se vier vazia).

        Lança OciHttpError se a OCI responder com erro e
        requests.RequestException se houver falha de rede.
        """
        logger.debug("%s %s", metodo, url)

        # 3. O parâmetro auth faz a assinatura. Usar json= já serializa o corpo
        #    e define o Content-Type, que também entra no cálculo da assinatura.
        resposta = self._sessao.request(
            metodo,
            url,
            params=params,
            json=corpo,
            auth=self._assinador,
            timeout=self._timeout,
        )

        # 4. Verifica o status antes de tentar ler o corpo.
        if not resposta.ok:
            raise OciHttpError.a_partir_da_resposta(resposta)

        # 5. DELETE e PUT podem responder sem corpo.
        if not resposta.content:
            return None
        return resposta.json()

    def fechar(self) -> None:
        """Libera as conexões abertas."""
        self._sessao.close()
