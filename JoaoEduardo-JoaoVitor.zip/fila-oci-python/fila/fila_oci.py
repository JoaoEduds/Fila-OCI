"""
Operações da API REST do OCI Queue (versão 20210201).

No original, as URLs eram montadas no meio da lógica de negócio. Aqui elas
ficam isoladas nesta classe, e quem a usa só chama métodos com nomes claros
(receber, apagar, adiar, publicar).

Referência da API: https://docs.oracle.com/en-us/iaas/api/#/en/queue/20210201/
"""

from dataclasses import dataclass
from typing import Iterable, List, Optional
from urllib.parse import quote

from .oci_http import OciHttpClient

VERSAO_API = "20210201"


@dataclass(frozen=True)
class Mensagem:
    """Uma mensagem lida da fila."""

    id: int
    conteudo: str
    # O receipt identifica esta entrega da mensagem. Ele é necessário para
    # apagar ou alterar a mensagem, e muda a cada nova entrega.
    receipt: str
    # Quantas vezes a mensagem já foi entregue (útil para os logs).
    entregas: int


class FilaOci:
    """Representa uma fila específica da OCI."""

    def __init__(self, http: OciHttpClient, endpoint: str, queue_id: str):
        self._http = http
        self._queue_id = queue_id
        self._base = f"{endpoint}/{VERSAO_API}/queues/{quote(queue_id, safe='')}/messages"

    def _url_da_mensagem(self, receipt: str) -> str:
        # O receipt pode ter caracteres como "+", "/" e "=", então precisa
        # ser codificado para não quebrar a URL (o original não fazia isso).
        return f"{self._base}/{quote(receipt, safe='')}"

    def receber(self, limite: int, espera_segundos: int, canal: Optional[str] = None) -> List[Mensagem]:
        """
        GET /messages. Busca até `limite` mensagens.

        Com `espera_segundos` > 0, a OCI faz long polling: segura a requisição
        até chegar uma mensagem ou o tempo acabar. Assim não precisamos de um
        sleep fixo entre as consultas.

        Com `canal`, só são retornadas mensagens daquele canal (channelFilter).
        """
        params = {"limit": limite, "timeoutInSeconds": espera_segundos}
        if canal:
            params["channelFilter"] = canal
        resposta = self._http.requisitar("GET", self._base, params=params) or {}

        return [
            Mensagem(
                id=item["id"],
                conteudo=item.get("content", ""),
                receipt=item["receipt"],
                entregas=item.get("deliveryCount", 1),
            )
            for item in resposta.get("messages", [])
        ]

    def apagar(self, receipt: str) -> None:
        """DELETE /messages/{receipt}. Confirma o processamento e tira a mensagem da fila."""
        self._http.requisitar("DELETE", self._url_da_mensagem(receipt))

    def adiar(self, receipt: str, segundos: int) -> None:
        """
        PUT /messages/{receipt}. Muda a visibilidade da mensagem.

        A mensagem continua na fila, mas fica invisível por `segundos`.
        Depois disso, ela volta a ser entregue para uma nova tentativa.
        """
        self._http.requisitar(
            "PUT",
            self._url_da_mensagem(receipt),
            corpo={"visibilityInSeconds": segundos},
        )

    def publicar(self, conteudos: Iterable[str], canal: Optional[str] = None) -> List[int]:
        """POST /messages. Publica mensagens (opcionalmente num canal) e devolve os IDs gerados."""
        entradas = []
        for conteudo in conteudos:
            entrada = {"content": conteudo}
            if canal:
                entrada["metadata"] = {"channelId": canal}
            entradas.append(entrada)
        corpo = {"messages": entradas}
        resposta = self._http.requisitar("POST", self._base, corpo=corpo) or {}
        return [m["id"] for m in resposta.get("messages", [])]
