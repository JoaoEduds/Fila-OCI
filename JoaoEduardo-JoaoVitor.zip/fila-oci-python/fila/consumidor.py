"""
Lógica central do exemplo: consumir a fila e enviar um e-mail por mensagem.

O fluxo é o mesmo do app.js original:
  1. busca mensagens na fila;
  2. para cada uma, envia o e-mail;
  3. deu certo: apaga a mensagem da fila;
  4. deu errado: deixa a mensagem invisível por alguns segundos, para ela
     voltar e ser tentada de novo.

Correções em relação ao original:
  * o conteúdo da mensagem é lido como JSON. O original acessava
    msgFila.email e msgFila.msg, que não existem: a OCI entrega o texto
    publicado no campo "content";
  * as mensagens são processadas uma de cada vez, aguardando cada etapa
    (o forEach(async ...) do original não esperava nada);
  * uma falha de rede ou da OCI não derruba o consumidor. Ele espera um
    pouco e tenta de novo, com intervalo crescente.
"""

import json
import logging
import time
from dataclasses import dataclass

from requests import RequestException

from .config import ConfigFila
from .email_sender import EnviadorEmail
from .fila_oci import FilaOci, Mensagem
from .oci_http import OciHttpError

logger = logging.getLogger(__name__)

# Intervalos de espera quando a OCI ou a rede falham (backoff exponencial).
ESPERA_INICIAL_ERRO = 2
ESPERA_MAXIMA_ERRO = 60


class MensagemInvalidaError(ValueError):
    """O conteúdo da mensagem não está no formato esperado."""


@dataclass(frozen=True)
class PedidoEmail:
    """O que vem dentro de cada mensagem: {"email": "...", "msg": "..."}."""

    email: str
    msg: str

    @classmethod
    def a_partir_do_conteudo(cls, conteudo: str) -> "PedidoEmail":
        try:
            dados = json.loads(conteudo)
        except json.JSONDecodeError as erro:
            raise MensagemInvalidaError(f"conteúdo não é um JSON válido: {erro}") from erro

        if not isinstance(dados, dict):
            raise MensagemInvalidaError("o JSON precisa ser um objeto")

        email = str(dados.get("email", "")).strip()
        msg = str(dados.get("msg", "")).strip()
        if "@" not in email:
            raise MensagemInvalidaError(f"campo 'email' ausente ou inválido: {email!r}")
        if not msg:
            raise MensagemInvalidaError("campo 'msg' ausente ou vazio")
        return cls(email=email, msg=msg)


class ConsumidorEmail:
    """Fica lendo a fila e transforma cada mensagem em um e-mail enviado."""

    def __init__(self, fila: FilaOci, enviador: EnviadorEmail, config: ConfigFila, assunto: str):
        self._fila = fila
        self._enviador = enviador
        self._config = config
        self._assunto = assunto

    def executar(self) -> None:
        """Loop principal. Roda até ser interrompido (Ctrl+C)."""
        logger.info("Aguardando mensagens na fila %s (canal: %s)", self._config.queue_id, self._config.canal or "todos")
        espera_erro = ESPERA_INICIAL_ERRO

        while True:
            try:
                mensagens = self._fila.receber(
                    self._config.limite_mensagens, self._config.espera_segundos, self._config.canal
                )
            except OciHttpError as erro:
                if not erro.eh_temporario:
                    # 401, 403 ou 404 indicam credencial, permissão ou OCID
                    # errado. Tentar de novo não resolve, então paramos.
                    raise
                espera_erro = self._aguardar_apos_erro(erro, espera_erro)
                continue
            except RequestException as erro:
                espera_erro = self._aguardar_apos_erro(erro, espera_erro)
                continue

            espera_erro = ESPERA_INICIAL_ERRO  # a comunicação voltou ao normal

            if not mensagens:
                logger.info("Nenhuma mensagem disponível. Verificando novamente...")
                continue

            for mensagem in mensagens:
                self.processar(mensagem)

    def processar(self, mensagem: Mensagem) -> None:
        """Trata uma única mensagem (público para facilitar os testes)."""
        logger.info("Mensagem recebida (id=%s, entrega nº %s): %s", mensagem.id, mensagem.entregas, mensagem.conteudo)

        try:
            pedido = PedidoEmail.a_partir_do_conteudo(mensagem.conteudo)
        except MensagemInvalidaError as erro:
            # Uma mensagem malformada nunca vai dar certo, então não adianta
            # adiar. Ela é deixada como está: volta depois do tempo de
            # visibilidade padrão da fila e, se houver Dead Letter Queue
            # configurada, vai para lá ao atingir o limite de entregas.
            logger.error("Mensagem %s ignorada, formato inválido: %s", mensagem.id, erro)
            return

        try:
            self._enviador.enviar(pedido.email, self._assunto, pedido.msg)
        except Exception as erro:  # qualquer falha no envio deve gerar nova tentativa
            logger.warning(
                "Falha ao enviar e-mail da mensagem %s (%s). Ela volta para a fila em %ss.",
                mensagem.id, erro, self._config.visibilidade_falha_segundos,
            )
            self._tentar(self._fila.adiar, mensagem.receipt, self._config.visibilidade_falha_segundos)
            return

        # Só apaga depois de ter certeza de que o e-mail saiu.
        self._tentar(self._fila.apagar, mensagem.receipt)
        logger.info("Mensagem %s processada e removida da fila.", mensagem.id)

    @staticmethod
    def _tentar(operacao, *args) -> None:
        """
        Executa apagar/adiar sem derrubar o consumidor se falhar.

        Se não der para apagar, a mensagem volta para a fila sozinha quando o
        tempo de visibilidade acabar. O pior caso é um e-mail duplicado, nunca
        um e-mail perdido.
        """
        try:
            operacao(*args)
        except (OciHttpError, RequestException) as erro:
            logger.error("Não foi possível executar %s na fila: %s", operacao.__name__, erro)

    @staticmethod
    def _aguardar_apos_erro(erro: Exception, espera: int) -> int:
        logger.warning("Erro ao consultar a fila (%s). Nova tentativa em %ss.", erro, espera)
        time.sleep(espera)
        return min(espera * 2, ESPERA_MAXIMA_ERRO)
