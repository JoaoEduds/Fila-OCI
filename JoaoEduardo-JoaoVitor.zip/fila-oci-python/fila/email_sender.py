"""
Envio de e-mail.

O original usava o nodemailer com callback. Por isso, um erro no envio nunca
chegava ao try/catch do consumidor, e a mensagem era apagada da fila mesmo
quando o e-mail falhava. Aqui o envio é síncrono e qualquer falha vira
exceção, então o consumidor sabe quando precisa tentar de novo.

Existem duas implementações com a mesma interface:
  * EnviadorSmtp: envia de verdade (Gmail, Outlook etc.);
  * EnviadorConsole: só registra no log, para testar a fila sem SMTP.
"""

import logging
import smtplib
from email.message import EmailMessage
from typing import Protocol

from .config import ConfigEmail

logger = logging.getLogger(__name__)


class EnviadorEmail(Protocol):
    """Interface comum a qualquer forma de envio de e-mail."""

    def enviar(self, destinatario: str, assunto: str, corpo_html: str) -> None:
        """Envia o e-mail ou lança uma exceção se não conseguir."""


class EnviadorSmtp:
    """Envia e-mails por SMTP com STARTTLS (porta 587 por padrão)."""

    def __init__(self, config: ConfigEmail, timeout_segundos: float = 30):
        self._config = config
        self._timeout = timeout_segundos

    def enviar(self, destinatario: str, assunto: str, corpo_html: str) -> None:
        mensagem = EmailMessage()
        mensagem["From"] = self._config.remetente
        mensagem["To"] = destinatario
        mensagem["Subject"] = assunto
        # Versão em texto simples para clientes que não exibem HTML.
        mensagem.set_content("Este e-mail tem conteúdo em HTML.")
        mensagem.add_alternative(corpo_html, subtype="html")

        with smtplib.SMTP(self._config.servidor, self._config.porta, timeout=self._timeout) as smtp:
            smtp.starttls()
            smtp.login(self._config.usuario, self._config.senha)
            smtp.send_message(mensagem)

        logger.info("E-mail enviado para %s", destinatario)


class EnviadorConsole:
    """Não envia nada: só mostra no log o que seria enviado."""

    def enviar(self, destinatario: str, assunto: str, corpo_html: str) -> None:
        logger.info("[simulação] E-mail para %s | assunto: %s | corpo: %s", destinatario, assunto, corpo_html)


def criar_enviador(config: ConfigEmail) -> EnviadorEmail:
    """Escolhe a implementação de acordo com EMAIL_MODO."""
    if config.modo == "smtp":
        return EnviadorSmtp(config)
    return EnviadorConsole()
