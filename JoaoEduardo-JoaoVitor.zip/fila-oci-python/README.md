# Filas da OCI em Python

Reimplementação em Python do exemplo `appdemo3fila` (Node.js): um **consumidor** que lê mensagens de uma fila do OCI Queue, envia um e-mail para cada uma e confirma o processamento.

## Lógica central (mantida do original)

1. Busca até N mensagens na fila (`GET /messages`), com requisições REST **assinadas** com a chave da OCI.
2. Para cada mensagem, lê `email` e `msg` e envia o e-mail.
3. **Sucesso:** apaga a mensagem (`DELETE /messages/{receipt}`).
4. **Falha:** deixa a mensagem invisível por 30 s (`PUT /messages/{receipt}` com `visibilityInSeconds`) para ela voltar à fila e ser tentada de novo.
5. Repete para sempre.

Formato esperado de cada mensagem:

```json
{"email": "destinatario@exemplo.com", "msg": "<b>Corpo do e-mail em HTML</b>"}
```

## Estrutura

| Arquivo | Responsabilidade | Equivale a |
|---|---|---|
| `app.py` | Ponto de entrada (comandos `consumir` e `publicar`) | `consumir()` no fim do `app.js` |
| `fila/config.py` | Lê e valida as variáveis de ambiente | constantes fixas no `app.js` |
| `fila/oci_http.py` | Requisições HTTP assinadas para a OCI | `ociHttpRequest.js` |
| `fila/fila_oci.py` | Operações da API do Queue (receber, apagar, adiar, publicar, com suporte a canal) | URLs montadas dentro do `app.js` |
| `fila/email_sender.py` | Envio de e-mail (SMTP ou simulado) | `enviarEmail` |
| `fila/consumidor.py` | Loop de consumo e regra de sucesso/falha | `consumir` |
| `tests/` | Testes automatizados sem acessar a OCI | (não existia) |

## Como executar

Pré-requisitos: Python 3.9+, uma fila criada na OCI e o arquivo `~/.oci/config` configurado (o mesmo da OCI CLI).

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # preencha OCI_QUEUE_ID e OCI_QUEUE_ENDPOINT

python app.py publicar --email voce@exemplo.com --msg "<b>Olá da fila!</b>"
python app.py consumir             # Ctrl+C para parar
python -m unittest -v              # testes
```

Com `EMAIL_MODO=console`, o e-mail só aparece no terminal. Para enviar de verdade, use `EMAIL_MODO=smtp` e preencha as variáveis `SMTP_*`. No Gmail, é preciso gerar uma *senha de app*.

O usuário da OCI precisa de uma política como:

```
Allow group <seu-grupo> to manage queues in compartment <seu-compartimento>
```

## Melhorias em relação ao original

### Erros corrigidos

| Problema no original | Solução |
|---|---|
| Lia `msgFila.email` e `msgFila.msg`, que não existem. A OCI entrega o texto publicado no campo `content`. | O `content` é lido como JSON e validado (`PedidoEmail`). |
| O `nodemailer` era usado sem `require`, e o envio usava callback. Assim, uma falha no envio nunca chegava ao `catch`, e a mensagem era apagada mesmo sem o e-mail ter saído. | O envio é síncrono e lança exceção. A mensagem só é apagada depois que o e-mail sai. |
| `forEach(async ...)` não espera as promessas. O loop já buscava mais mensagens enquanto as anteriores ainda estavam sendo processadas. | As mensagens são processadas em sequência, uma etapa de cada vez. |
| `ociHttpRequest` engolia os erros e devolvia `null`. Depois, `retorno.messages` estourava e derrubava o consumidor. | Os erros viram `OciHttpError` com status, código e `opc-request-id`. |
| O status HTTP nunca era verificado (um 401 era tratado como sucesso). | Toda resposta diferente de 2xx gera exceção. |
| O `receipt` ia na URL sem codificação. | O `receipt` é codificado com `quote`. |

### Boas práticas aplicadas

- **Sem segredos no código:** OCID, endpoint e senha do SMTP vêm do `.env`, que está no `.gitignore`.
- **Validação da configuração** no início, com mensagens claras e limites da API (por exemplo, `limit` de 1 a 20).
- **Long polling** (`timeoutInSeconds`) no lugar do `sleep` fixo de 5 s: a mensagem é recebida assim que chega.
- **Resiliência:** falhas de rede ou erros 429/5xx geram nova tentativa com espera crescente (2, 4, 8... até 60 s). Erros de credencial (401/403/404) encerram o programa com a explicação.
- **Responsabilidades separadas** em módulos, com *type hints*, *docstrings* e `dataclasses`.
- **Logging** com data, nível e origem, no lugar de `console.log`.
- **Interface `EnviadorEmail`:** permite trocar SMTP por simulação, o que facilita os testes.
- **Testes unitários** dos três caminhos: sucesso, falha no envio e mensagem inválida.
- **Suporte a canais** (`FILA_CANAL` ou `--canal`): o produtor publica num canal e o consumidor filtra por ele.
- **Comando `publicar`**, para testar o consumidor sem usar o console da OCI.
- **Encerramento limpo** com Ctrl+C, fechando as conexões.

### Observação sobre mensagens inválidas

Uma mensagem que não está no formato JSON esperado nunca vai ser processada com sucesso. Por isso, ela é registrada no log e deixada na fila: volta depois do tempo de visibilidade padrão e, se a fila tiver uma **Dead Letter Queue** configurada, vai para lá ao atingir o limite de entregas. Assim, nenhum dado é descartado em silêncio.
