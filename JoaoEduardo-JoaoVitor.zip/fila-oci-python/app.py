"""
Ponto de entrada da aplicação.

Uso:
    python app.py consumir
        Fica lendo a fila e enviando um e-mail para cada mensagem
        (é o que o app.js original fazia).

    python app.py publicar --email fulano@exemplo.com --msg "<b>Olá!</b>"
        Publica uma mensagem no formato esperado pelo consumidor.
        Não existia no original e serve para testar o consumidor.
"""

import argparse
import json
import logging
import sys

from fila.config import ConfiguracaoInvalidaError, carregar_configuracao
from fila.consumidor import ConsumidorEmail
from fila.email_sender import criar_enviador
from fila.fila_oci import FilaOci
from fila.oci_http import OciHttpClient, OciHttpError

logger = logging.getLogger("app")


def criar_argumentos() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Exemplo de uso do OCI Queue em Python.")
    parser.add_argument("-v", "--verbose", action="store_true", help="mostra logs de depuração")
    comandos = parser.add_subparsers(dest="comando", required=True)

    comandos.add_parser("consumir", help="consome a fila e envia os e-mails")

    publicar = comandos.add_parser("publicar", help="publica uma mensagem de teste na fila")
    publicar.add_argument("--email", required=True, help="destinatário do e-mail")
    publicar.add_argument("--msg", required=True, help="corpo do e-mail (pode ser HTML)")
    publicar.add_argument("--canal", help="canal da fila (padrão: FILA_CANAL do .env)")
    return parser


def main() -> int:
    args = criar_argumentos().parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )

    try:
        config = carregar_configuracao()
    except ConfiguracaoInvalidaError as erro:
        logger.error("Configuração inválida: %s", erro)
        return 2

    # O timeout da rede precisa ser maior que o tempo de long polling.
    http = OciHttpClient(config.oci.arquivo, config.oci.perfil, timeout_segundos=config.fila.espera_segundos + 30)
    fila = FilaOci(http, config.fila.endpoint, config.fila.queue_id)

    try:
        if args.comando == "publicar":
            conteudo = json.dumps({"email": args.email, "msg": args.msg}, ensure_ascii=False)
            ids = fila.publicar([conteudo], args.canal or config.fila.canal)
            logger.info("Mensagem publicada. ID(s): %s", ids)
        else:
            consumidor = ConsumidorEmail(fila, criar_enviador(config.email), config.fila, config.email.assunto)
            consumidor.executar()
    except KeyboardInterrupt:
        logger.info("Encerrado pelo usuário.")
    except OciHttpError as erro:
        logger.error("Erro da OCI: %s", erro)
        return 1
    finally:
        http.fechar()

    return 0


if __name__ == "__main__":
    sys.exit(main())
