"""
Testes do consumidor sem acessar a OCI nem um servidor de e-mail.

A fila e o enviador são substituídos por versões falsas que só registram as
chamadas recebidas. Rodar com:  python -m unittest -v
"""

import unittest

from fila.config import ConfigFila
from fila.consumidor import ConsumidorEmail, MensagemInvalidaError, PedidoEmail
from fila.fila_oci import Mensagem

CONFIG = ConfigFila(
    queue_id="ocid1.queue.teste",
    endpoint="https://exemplo",
    limite_mensagens=10,
    espera_segundos=0,
    visibilidade_falha_segundos=30,
)


class FilaFalsa:
    def __init__(self):
        self.apagadas = []
        self.adiadas = []

    def apagar(self, receipt):
        self.apagadas.append(receipt)

    def adiar(self, receipt, segundos):
        self.adiadas.append((receipt, segundos))


class EnviadorFalso:
    def __init__(self, falhar=False):
        self.falhar = falhar
        self.enviados = []

    def enviar(self, destinatario, assunto, corpo_html):
        if self.falhar:
            raise ConnectionError("SMTP fora do ar")
        self.enviados.append((destinatario, assunto, corpo_html))


def mensagem(conteudo):
    return Mensagem(id=1, conteudo=conteudo, receipt="rcpt-1", entregas=1)


class TestPedidoEmail(unittest.TestCase):
    def test_le_json_valido(self):
        pedido = PedidoEmail.a_partir_do_conteudo('{"email": "a@b.com", "msg": "oi"}')
        self.assertEqual(pedido, PedidoEmail(email="a@b.com", msg="oi"))

    def test_rejeita_texto_que_nao_e_json(self):
        with self.assertRaises(MensagemInvalidaError):
            PedidoEmail.a_partir_do_conteudo("hello")

    def test_rejeita_email_ausente(self):
        with self.assertRaises(MensagemInvalidaError):
            PedidoEmail.a_partir_do_conteudo('{"msg": "oi"}')


class TestConsumidor(unittest.TestCase):
    def criar(self, falhar=False):
        fila, enviador = FilaFalsa(), EnviadorFalso(falhar)
        return ConsumidorEmail(fila, enviador, CONFIG, "Assunto"), fila, enviador

    def test_sucesso_envia_e_apaga(self):
        consumidor, fila, enviador = self.criar()
        consumidor.processar(mensagem('{"email": "a@b.com", "msg": "<b>oi</b>"}'))
        self.assertEqual(enviador.enviados, [("a@b.com", "Assunto", "<b>oi</b>")])
        self.assertEqual(fila.apagadas, ["rcpt-1"])
        self.assertEqual(fila.adiadas, [])

    def test_falha_no_envio_adia_e_nao_apaga(self):
        consumidor, fila, _ = self.criar(falhar=True)
        consumidor.processar(mensagem('{"email": "a@b.com", "msg": "oi"}'))
        self.assertEqual(fila.apagadas, [])
        self.assertEqual(fila.adiadas, [("rcpt-1", 30)])

    def test_mensagem_invalida_nao_envia_nem_mexe_na_fila(self):
        consumidor, fila, enviador = self.criar()
        consumidor.processar(mensagem("isso não é json"))
        self.assertEqual(enviador.enviados, [])
        self.assertEqual(fila.apagadas, [])
        self.assertEqual(fila.adiadas, [])


if __name__ == "__main__":
    unittest.main()
